<hr>
        <div class="footer">
            <p>PBKK 2020</p>
        </div>

<script type="text/javascript" src="<?php echo base_url('asset/js/jquery.printPage.js')?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $(".btnPrint").printPage();
    })
</script>

    </div>
</body>

